# Payment-Resource
A small Spring rest application integrate with Hibernate
